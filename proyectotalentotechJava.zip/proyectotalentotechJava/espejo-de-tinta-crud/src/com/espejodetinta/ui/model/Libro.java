package com.espejodetinta.ui.model;

public class Libro {
    
}
