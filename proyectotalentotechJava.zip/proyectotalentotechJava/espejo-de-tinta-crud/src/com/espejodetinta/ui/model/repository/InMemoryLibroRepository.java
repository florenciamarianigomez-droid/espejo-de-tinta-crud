package com.espejodetinta.ui.model.repository;

public class InMemoryLibroRepository {
    
}
