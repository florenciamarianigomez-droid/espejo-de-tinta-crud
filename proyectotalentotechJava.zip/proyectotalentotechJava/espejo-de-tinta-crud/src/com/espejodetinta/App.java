package com.espejodetinta;

import com.espejodetinta.ui.ConsoleUI;

public class App {
    public static void main(String[] args) {
        new ConsoleUI().run();
    }
}
